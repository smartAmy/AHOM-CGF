clear;
addpath('Datasets/');
addpath('measure/');
addpath('funs/');
load('3sources.mat');

gt = Y;
X= cellfun(@(x) x', X, 'UniformOutput', false);

V = length(X);                  
c = length(unique(gt));
N = size(X{1},2);                   
weight_vector = ones(1,V)';      
p = 0.9;                
knn_size = 10; 

nOrder = 4;     
beta = 0.01;
lambda = 0.1; 

for i=1:V
    X{i} = X{i}./repmat(sqrt(sum(X{i}.^2,1)),size(X{i},1),1);
end

for i = 1:V
    S{i} = constructW_PKN(X{i}, knn_size);
    T = cell(1, nOrder);
    T{1} = eye(N);
    T{2} = S{i};
    for k = 3:nOrder
        T{k} = 2*S{i}*T{k-1} - T{k-2};
    end
    
    
    if nOrder == 1
        Z{i} = T{1};  
    elseif nOrder == 2
        Z{i} = T{2};  
    else
        Z{i} = T{nOrder};  
    end
    
    J{i} = zeros(N, N);
    G{i} = zeros(N, N);  
end

Z_tensor = cat(3, Z{:,:});
J_tensor = cat(3, J{:,:});

kesai = -1;
iter = 1;
max_iter = 200;
gamma = 1/V * ones(1, V);
sX = [N, N, V];  
mu = 1e-3;
mu_max = 1e8;
rho = 1.2;
tol = 1e-4;
A = zeros(N,N);

%%  == outer loop ==
while iter <= max_iter
    Zpre=Z_tensor;
    Jpre=J_tensor;
    %% == update A ==
    if iter ==1
       [Y, A] = CLR(gamma,Z,c,lambda);
    else
       [Y, A] = CLR(gamma,Z,c,lambda,A0);
    end
    A0 = A;

    %% == update Tensor J ==
    for v =1:V
     QQ{v}=(Z{v} + G{v}/mu);
    end
    Q_tensor = cat(3,QQ{:,:});
    Qg = Q_tensor(:);

    [z, objV] = wshrinkObj_weight_lp(Qg, weight_vector./mu,sX,0,3,p);
    J_tensor = reshape(z, sX);
    
    for k=1:V
        J{k} = J_tensor(:,:,k);
    end
    
    %% update gamma 
    for j = 1:V
        J_var{j} = norm(A - Z{i}, 'fro')^2;
    end
    for i = 1:V
        gamma(i) = (- J_var{i} / kesai*beta)^(1 / (kesai - 1));
    end

    %% == update Z{i} == 
    tmp_gamma(i)=gamma(i);
    for i = 1:V
       D{i} = J{i} - G{i}/mu;
    end
    M1 = 2*eye(N)*tmp_gamma(i) + mu * eye(N); 
    for j = 1:V      
        M2 = 2*A*tmp_gamma(i)+ mu * D{i}; 
        Z{i} = M1 \ M2;
    end
    Z_tensor = cat(3, Z{:,:});
 
    %% == update Y1,Y2 ==
    for i=1:V
        G{i} = G{i}+mu*(Z{i}-J{i});
    end
    
    %% == update pho1,2 ==
    mu = mu*rho;

    %% check convergence
    difZ = max(abs(Z_tensor(:)-Zpre(:)));
    difJ = max(abs(J_tensor(:)-Jpre(:)));
    err = max([difZ,difJ]);
    if err < tol
        break;
    end

    iter = iter + 1;
end

res = myNMIACCwithmean(A,gt,c) % [ACC nmi Purity Fscore Precision Recall AR Entropy]